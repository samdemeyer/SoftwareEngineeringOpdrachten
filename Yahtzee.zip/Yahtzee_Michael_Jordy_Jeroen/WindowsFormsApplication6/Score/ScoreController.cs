﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Yahtzee
{
    public class ScoreController
    {
        private ScoreModel scoreModel;
        private ScoreUI scoreUI;
        private List<DiceController> dices;

        public ScoreController( List<DiceController> dices)
        {
            this.dices = dices;
            this.scoreModel = new ScoreModel();
            this.scoreUI = new ScoreUI();
        }

        // Method that returns view
        public ScoreUI view
        {
            get
            {
                return this.scoreUI;
            }
        }



        // Chance           CHECK   0
        // 1'en             CHECK   1
        // 2'en             CHECK   2
        // 3'en             CHECK   3
        // 4'en             CHECK   4
        // 5'en             CHECK   5
        // 6'en             CHECK   6
        // Three of a kind  CHECK   7
        // Four of a kind   CHECK   8
        // Full House       CHECK   9
        // Small Straight   CHECK   10
        // Large Straight   CHECK   11
        // Yahtzee          CHECK   12

        bool[] statusAllScores = new bool[13];   // Deze array houd bij welke methods al eens zijn gebruikt en welke niet, elke method mag maar 1 keer gebruikt worden
        int[] allScores = new int[13];           // Dit houd voor elke worp alle scores bij die de methods gaan returnen

        public int CalculateThreeOfAKind(int[] myDice)
        {
            int Sum = 0;

            bool ThreeOfAKind = false;

            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (myDice[j] == i)
                        Count++;

                    if (Count > 2)
                    {
                        ThreeOfAKind = true;
                        this.scoreModel.besteWorp = "Het is Three of a kind!";
                       
                    }
                }
            }

            if (ThreeOfAKind)
            {
                for (int k = 0; k < 5; k++)
                {
                    
                    Sum += myDice[k];
                }
            }

            return Sum;
            
        }
        public int CalculateFourOfAKind(int[] myDice)
        {
            int Sum = 0;

            bool FourOfAKind = false;

            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (myDice[j] == i)
                        Count++;

                    if (Count > 3)
                    {
                        FourOfAKind = true;

                        this.scoreModel.besteWorp = "Het is Four of a kind!";
                       
                    }
                }
            }

            if (FourOfAKind)
            {
                for (int k = 0; k < 5; k++)
                {
                    Sum += myDice[k];
                }
            }

            return Sum;
        }
        public int CalculateFullHouse(int[] myDice)
        {
            int Sum = 0;

            int[] i = new int[5];

            i[0] = myDice[0];
            i[1] = myDice[1];
            i[2] = myDice[2];
            i[3] = myDice[3];
            i[4] = myDice[4];

            Array.Sort(i);

            if ((((i[0] == i[1]) && (i[1] == i[2])) && // Three of a Kind
                 (i[3] == i[4]) && // Two of a Kind
                 (i[2] != i[3])) ||
                ((i[0] == i[1]) && // Two of a Kind
                 ((i[2] == i[3]) && (i[3] == i[4])) && // Three of a Kind
                 (i[1] != i[2])))
            {

                this.scoreModel.besteWorp = "Het is een Full House!";
                Sum = 25;
            }

            return Sum;
        }
        public int CalculateSmallStraight(int[] myDice)
        {
            int Sum = 0;

            int[] i = new int[5];

            i[0] = myDice[0];
            i[1] = myDice[1];
            i[2] = myDice[2];
            i[3] = myDice[3];
            i[4] = myDice[4];

            Array.Sort(i);

            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (i[j] == i[j + 1])
                {
                    temp = i[j];

                    for (int k = j; k < 4; k++)
                    {
                        i[k] = i[k + 1];
                    }

                    i[4] = temp;
                }
            }

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5)) ||
                ((i[0] == 3) && (i[1] == 4) && (i[2] == 5) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 2) && (i[3] == 3) && (i[4] == 4)) ||
                ((i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                this.scoreModel.besteWorp = "Het is een Small Straight!";
                Sum = 30;
            }

            return Sum;
        }
        public int CalculateLargeStraight(int[] myDice)
        {
            int Sum = 0;

            int[] i = new int[5];

            i[0] = myDice[0];
            i[1] = myDice[1];
            i[2] = myDice[2];
            i[3] = myDice[3];
            i[4] = myDice[4];

            Array.Sort(i);

            if (((i[0] == 1) &&
                 (i[1] == 2) &&
                 (i[2] == 3) &&
                 (i[3] == 4) &&
                 (i[4] == 5)) ||
                ((i[0] == 2) &&
                 (i[1] == 3) &&
                 (i[2] == 4) &&
                 (i[3] == 5) &&
                 (i[4] == 6)))
            {
                this.scoreModel.besteWorp = "Het is een Large Straight!";
                Sum = 40;
            }

            return Sum;
        }
        public int CalculateYahtzee(int[] myDice)
        {
            int Sum = 0;

            for (int i = 1; i <= 6; i++)
            {
                int Count = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (myDice[j] == i)
                        Count++;

                    if (Count > 4)
                    {
                        this.scoreModel.besteWorp = "Yathzee!";
                        Sum = 50;
                    }
                }
            }

            return Sum;
        }
        public int AddUpChance(int[] myDice)
        {
            int Sum = 0;

            for (int i = 0; i < 5; i++)
            {
                Sum += myDice[i];
            }
            this.scoreModel.besteWorp = "Chance!";
            return Sum;
        }
        public int AddUpDice(int DiceNumber, int[] myDice)
        {
            int Sum = 0;

            for (int i = 0; i < 5; i++)
            {
                if (myDice[i] == DiceNumber)
                {
                    Sum += DiceNumber;
                }
            }
            if (Sum != 0)
            {
                this.scoreModel.besteWorp = DiceNumber + "'en in je worp.";
            }
            return Sum;
        }
        public void GetAllScores(int[] diceValues)   // Berekent elke worp alle mogelijke scores
        {
            allScores[0] = AddUpChance(diceValues);
            allScores[1] = AddUpDice(1, diceValues);
            allScores[2] = AddUpDice(2, diceValues);
            allScores[3] = AddUpDice(3, diceValues);
            allScores[4] = AddUpDice(4, diceValues);
            allScores[5] = AddUpDice(5, diceValues);
            allScores[6] = AddUpDice(6, diceValues);
            allScores[7] = CalculateThreeOfAKind(diceValues);
            allScores[8] = CalculateFourOfAKind(diceValues);
            allScores[9] = CalculateFullHouse(diceValues);
            allScores[10] = CalculateSmallStraight(diceValues);
            allScores[11] = CalculateLargeStraight(diceValues);
            allScores[12] = CalculateYahtzee(diceValues);
        }
        public int HighestScore()    // Geeft de hoogste score terug en zet bijbehorende bool op true omdat deze al gebruikt is
        {
            int highestScore = allScores.Max();                                 // Zoekt het hoogste cijfer in de array
            int indexHighestScore = Array.IndexOf(allScores, highestScore);     // Zoekt de index van het hoogste cijfer in de array
            return allScores[indexHighestScore];
        }

        // Method that gets executed when the observable is changed
        public void notify( int newDiceValue )
        {
            int score = 0;
            int[] diceValues = new int[5];

            foreach (DiceController dice in this.dices )
            {
                //score += dice.diceModel.value;
                //Elke waarde van elke dice wordt hier opgevraagd dus mss hier eens zien voor de score te fixen
            }

            DiceController[] dicesArray = dices.ToArray();

            for (int i = 0; i < dicesArray.Length; i++)
            {
                diceValues[i] = dicesArray[i].diceModel.value;
            }

            GetAllScores(diceValues);
            score = HighestScore();
            // Update model with new value
            this.scoreModel.score = score;
            
            // Update view with new value
            this.scoreUI.updateScore(score);
            this.scoreUI.updateBesteWorp(this.scoreModel.besteWorp);
        }



        // vanaf hier de code om player.txt te beheren


    }
}
