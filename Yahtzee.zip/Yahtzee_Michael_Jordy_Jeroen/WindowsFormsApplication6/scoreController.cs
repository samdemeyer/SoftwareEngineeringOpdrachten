﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yahtzee
{
    class ScoreController
    {

        private ScoreUi _scoreUI;
        private ScoreModel __scoreModel;

    }
}
